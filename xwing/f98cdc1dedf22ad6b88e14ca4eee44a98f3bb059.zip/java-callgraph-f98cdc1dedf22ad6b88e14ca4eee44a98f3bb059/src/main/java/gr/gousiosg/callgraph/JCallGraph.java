package gr.gousiosg.callgraph;

public class JCallGraph 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
