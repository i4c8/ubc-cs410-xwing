Java Call Graph Utils
=====================

A suite of programs for generating static and dynamic call graphs in Java.




-Known Restrictions

* The static call graph generator does not account for methods invoked using
  reflection.  
  
Author
------

Georgios Gousios <gousiosg@gmail.com>

License
-------

2-clause BSD